# zhuying-yewu-fenxi｜立项报告·主营业务分析

## 两阶段固定模板

调用写作时先询问“早前期（伊隆纬特）还是中后期（因诺科技）”，用户回答后按对应标题逐项填入当前公司资料。同项目连续调用复用明确答案。完整标题见 [早前期](references/template-early.md)、[中后期](references/template-mid-late.md)；执行与校验见 [阶段模板规则](references/stage-template-workflow.md)。旧版自动选型和标题自由调整已取消。

撰写一级市场股权投资立项报告中"三、主营业务分析"章节的 Claude 技能（v2）。

## v2 核心变化

v1 是一套教科书式的 12 节固定框架；v2 以两篇内部范文为母版重建：

1. **两套母版结构**：多板块式（因诺科技型，板块五段式）与单主线式（伊隆纬特型，产品→技术→模式→上下游→竞对→预测），由用户明确选择早前期或中后期，完整标题以原文模板为准；
2. **写作基因系统**（`references/writing-dna.md`）：结论前置三层法、四拍技术优势法、订单五要素、客户背景小传、市场空间四句式、客户评价三段式、规划三段式、章末预测收束；
3. **会议纪要升级为一级信源**：附纪要挖掘清单（订单、市占率、竞对关系、定价机制、渗透深度、规划目标）；
4. **联网补研协议**（`references/research-protocol.md`）：竞对财务与估值、市场空间锚点、战略客户背景、企业自述核验；
5. **语言禁令**：全文禁用"标的公司"（直接写公司简称）、禁用"不是…而是/不仅…而且"等对举连词、禁机械总结腔，附改写示例；
6. **风险内嵌**：随范文取消独立风险章与空泛小结，风险以劣势三段式与实际约束及影响嵌入正文，重大风险时才增设独立节；
7. **公文排版与字体自动化**（v2.2，三技能统一）：内置集团《行文规范性格式模板》全套规则（方正小标宋二号主标题、仿宋_GB2312三号正文、28磅固定行距、A4公文页边距、外侧奇偶页码）；表格全五号、中文仿宋_GB2312及括注楷体_GB2312、西文Times New Roman；表头首行加粗并加浅蓝底（#D9E2F3）、表头行跨页重复、宽度按窗口自动调整、所有单元格居中；渲染由与 hangye-fenxi / gongsi-qingkuang 共用的 `scripts/build_docx.py` 统一完成，不再手写排版代码；三个公文字体随技能分发，`scripts/ensure_fonts.py` 自动检测安装（备用 `ensure-fonts.ps1`，assets 缺失时自动从本仓库下载）。

## 文件结构

```
zhuying-yewu-fenxi/
├── SKILL.md                        # 主流程：身份、三条铁律、七步法、数据红线
├── references/
│   ├── writing-dna.md              # 范文写作基因解构（含范文瑕疵清单）
│   ├── chapter-template.md         # 固定模板内的内容方法+表格+证据覆盖底线
│   ├── language-style.md           # 禁令清单+句式库+改写示例
│   ├── research-protocol.md        # 联网检索协议
│   ├── metrics-formulas.md         # 指标公式+交叉印证+数据充分性
│   ├── quality-checklist.md        # 输出前逐项自检
│   └── docx-format.md              # 公文排版规范（页面/字体层级/表格/统一渲染脚本）
├── scripts/
│   ├── build_docx.py               # 三技能统一 .docx 渲染脚本
│   ├── ensure_fonts.py             # 字体自动检测与用户级安装（Windows 含注册表注册）
│   ├── style_check.py              # 语言红线机械扫描
│   └── ensure-fonts.ps1            # 字体安装 PowerShell 备用方案（含 GitHub 下载兜底）
└── assets/fonts/
    ├── simfang.ttf                 # 仿宋_GB2312（正文/表格）
    ├── KaiTi_GB2312.ttf            # 楷体_GB2312（二级标题）
    └── FZXiaoBiaoSongJT.ttf        # 方正小标宋简体（主标题）
```

## 使用方式

上传目标公司的尽调资料包（BP、访谈/会议纪要、财务数据、订单台账、产品资料等任意组合），说明"写XX公司的主营业务分析"即可。资料缺口不阻断分析：缺口数据不写入报告正文与表格，随成稿在对话中输出"资料缺口与待核查清单"（缺什么、影响哪个判断、建议的补充渠道）；需要 Word 文档时说明即可由统一脚本生成公文排版 .docx。

## 跨 Agent 安装与调用

[下载完整技能 ZIP](https://github.com/Icdafy/Skills/raw/refs/heads/main/distributions/investment-report-skills/zhuying-yewu-fenxi.zip)。WorkBuddy、Kimi、Claude桌面版、Qoder及Trae的安装入口、目录差异和验收见 [跨 Agent 安装与调用](references/agent-compatibility.md)。

本技能名为 `zhuying-yewu-fenxi`。保留完整文件夹，启用后新建会话点名调用；可运行 `python scripts/skill_portability.py check --smoke` 检查资源及Word生成。技能发现与模型实际调用须在目标客户端按指引验收，不能仅凭复制文件认定成功。
