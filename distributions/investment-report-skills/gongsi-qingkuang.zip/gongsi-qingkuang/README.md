# 公司情况（gongsi-qingkuang）

当前分发版本：**2.0.1**；变更见 [CHANGELOG.md](CHANGELOG.md)。

## 用途与边界

公司主体、股权、团队、资质、融资和财务快照；不代写行业或主营业务章节。

## 输入和输出

输入：BP、尽调资料、访谈/会议纪要、工商/财务/股权资料与项目阶段。

输出：证据可追溯的公司情况正文、表格和 DOCX；缺口按原规则留底。

## 依赖与字体

Python 3.10+；安装和完整性检查使用标准库，DOCX 生成需 `requirements.txt` 中的 python-docx。

公开包不含字体。自行准备有使用权的仿宋、楷体_GB2312、方正小标宋等原版式字体，可用 `ICDAFY_FONT_DIR` 指向授权文件目录；运行 `python scripts/ensure_fonts.py --check` 检测。缺字体须明确说明，不能把草稿称为已通过实际版式验收；原字体、字号和版式规则保留。

## 完整安装例子

从 [单技能 ZIP](https://github.com/Icdafy/Skills/raw/refs/heads/main/distributions/investment-report-skills/gongsi-qingkuang.zip) 下载，解压后进入 `gongsi-qingkuang`；不要只复制 SKILL.md。本 PR 合并前可从当前分支 `gongsi-qingkuang/` 安装。

```powershell
cd "C:/下载/技能包/gongsi-qingkuang"
python -m pip install -r requirements.txt
python scripts/skill_portability.py check --smoke
python scripts/skill_portability.py install --agent codex --scope project --project-dir "C:/项目/示例 项目"
python scripts/skill_portability.py install --agent codex --scope project --project-dir "C:/项目/示例 项目" --apply
```

Claude Code 把 `--agent codex` 换成 `--agent claude-code`。其他客户端及安装器目录表见 [跨客户端安装](references/agent-compatibility.md)。运行路径以本次实际加载的 SKILL.md 目录为根；脚本和输入输出使用绝对路径时可在任意任务目录执行。

## 调用例子

安装后新建会话，在 Codex 输入：

```text
$gongsi-qingkuang 帮我写立项报告的公司情况；这是本期尽调资料，阶段尚未确定。
```

Claude Code 输入 `/gongsi-qingkuang 帮我写立项报告的公司情况；这是本期尽调资料，阶段尚未确定。`；自然语言直接使用“帮我写立项报告的公司情况；这是本期尽调资料，阶段尚未确定。”。先回答“早前期”或“中后期”，再填写该阶段的原固定模板。

## 已验证环境

Windows，Python 3.12.14。迁移后原375项用例完整发现，374通过、1项原Windows符号链接环境跳过；本技能ZIP在仓库外中文与空格路径执行 `check --smoke` 通过，项目安装、备份和本地文件保留已实测。

Codex CLI 0.160.0：新会话显式调用、自然语言和相邻技能反例均实际读取正确项目技能路径，路由通过。

Claude Code当前没有可运行客户端，未实测；其他客户端未实测。脚本成功不代替模型调用或Word视觉验收。原始提示、读取路径、结果和字体探针见 [验证记录](https://github.com/Icdafy/Skills/blob/main/docs/validation.md)。

## 升级入口

维护者只改 `gongsi-qingkuang/`，同步受影响的共享副本后执行 `python tools/package_skills.py --skill gongsi-qingkuang`（在整库根运行）；源码版本见 [VERSION](VERSION)，记录见 [CHANGELOG.md](CHANGELOG.md)。全部维护步骤见 [维护说明](https://github.com/Icdafy/Skills/blob/main/docs/maintenance.md)。

用户将新版解压到另一个目录，再用同样的 install 命令更新指定项目。已有安装先备份到 skills 目录外的 `skill-backups/`；出现多余文件会停止，手工确认后 `--replace --apply` 把旧目录移入备份。额外本地文件保留在备份中；确认内容后再决定是否迁入新版。源码保持在仓库根目录 `<仓库>/gongsi-qingkuang/`；GitHub 源码地址及安装后的英文目录名不变。

## 许可

[Apache-2.0](LICENSE)；[NOTICE](NOTICE) 保留署名、维护者素材授权确认和本机字体说明。

## 原业务说明与历史记录

# gongsi-qingkuang — 立项报告「公司情况」章节生成技能

## 两阶段固定模板

调用写作时先询问“早前期（2026-09 终稿范式）还是中后期（因诺科技）”，用户回答后按对应标题逐项填入当前公司资料。同项目连续调用复用明确答案。完整标题见 [早前期](references/template-early.md)、[中后期](references/template-mid-late.md)；执行与校验见 [阶段模板规则](references/stage-template-workflow.md)。旧版自动选型和标题自由调整已取消。

把一家拟投资公司的**尽调资料包＋会议纪要**，结合全网权威检索，炼成股权投资立项报告的「**四、公司情况**」章节。写作口径对齐一级市场投资机构内部金标准范文：客观、审慎、事实优先、证据可溯源，优势与瑕疵同台。

供投委会回答一个问题：**这家公司的主体、股权、团队、资源与合规状况，是否构成一笔可以推进的投资的基础条件。**

## 输出（双件套）

| 交付物 | 说明 |
| --- | --- |
| 章节正文 | 骨架与必要表格参照范文，正文按事实关系自然行文（两阶段分别保留原报告固定标题，历史事项均按事实逐项展开）；默认 Markdown，可一键渲染公文排版 .docx |
| 待补充资料及后续核查事项清单 | 随稿在对话回复中交付、不写入报告文件；每条写清查什么文件、走什么渠道、问什么问题，可直接转给尽调团队 |

事实台账保留完整来源；正文选择影响立项判断的信息，实质缺口在随稿清单交代。无关细节与用户删去的内容不自动回填。

## 输入三源

| 来源 | 独家供给 |
| --- | --- |
| 尽调资料包（工商资料、股权表、章程、审计报告、专利证书、花名册、BP、投资协议） | 全部硬数据 |
| 会议纪要／访谈纪要 | 书面资料查不到的软信息：子公司真实用途、代持形成原因、技术真实来源、公司对财务问题的解释、上市时间表、在手订单——解释、预测与仅口头信息保留归属，同段或同表不重复挂来源 |
| 联网检索 | 三大必检：机构股东背景识别（"机构简称，资金性质"格式）、客户供应商背景识别、官方规则与公开风险核验 |

## 使用方式

装载技能后上传资料，直接说：

- "写一下XX公司的公司情况"
- "根据资料包和会议纪要出公司情况章节"
- "把股权结构/历史沿革/核心团队整理成立项报告口径"

技能先等待用户选择阶段，再完成：建事实台账 → 榨取会议纪要 → 联网补缺与背景增强 → 公式勾稽＋十四对三角验证 → 按骨架起草 → 红旗扫描 → 语言红线扫描 → 机械勾稽自检 → 交付。

## 章节标题

早前期使用 2026-09 终稿范式第四章（设立背景开篇，28个源标题；伊隆纬特结构已停用）；中后期使用因诺原第二章和第五章，财务第六章不并入。所有子标题以两份完整对照及JSON为准。

## 语言红线（零容忍）

1. **禁用否定-肯定对照连词族**："不是……而是""并非……而是""不仅……而且""不但……还"等一律禁止；直接写肯定半句，对比拆成两个事实句，转折只用"但"。
2. **称谓只有两种**：默认主语"公司"，点名用公司简称；全文零"标的公司""该标的""目标公司"。
3. **结论先行**：每段首句点明该段核心，零铺垫、零"值得注意的是"式引子。

配套规则：本方团队汇报口吻；财务问题用数据及结论；已签、意向与确认收入分开；来源在段落或表格层统一交代，保留证据性质；材料版本和制作过程留底稿。正文不固定套四拍或判断加核查结尾。

## 文件结构

| 文件 | 用途 |
| --- | --- |
| `SKILL.md` | 触发条件、执行顺序、骨架、语言红线、写作准则 |
| `references/structure.md` | 施工图：事实台账、会议纪要挖掘清单、三角验证矩阵（14对）、逐节"写什么/为什么/怎么写"、裁剪规则 |
| `references/writing-craft.md` | 团队立场、自然段落、表文分工、来源与预测口径、成稿质检 |
| `references/review-feedback.md` | 修订及批注处置、删段与重写区别、脱敏提炼通用经验 |
| `references/data-and-tables.md` | 计算公式、口径与单位、勾稽自检清单、联网三大必检、标准表模板 T1–T21 |
| `references/red-flags.md` | 按文档位置索引的红旗模式库（现象→为什么危险→核查动作）＋组合拳规则 |
| `references/gold-examples.md` | 范文文体指纹与 14 个高质量段落逐一拆解 |
| `scripts/build_docx.py` | 内容 JSON → 公文排版 .docx（与 hangye-fenxi、zhuying-yewu-fenxi 共用的三技能统一渲染器） |
| `scripts/ensure_fonts.py` | 公文字体检测与用户级安装（仿宋_GB2312、楷体_GB2312、方正小标宋简体；Windows 含注册表注册） |
| `scripts/style_check.py` | 扫描语言红线、外部指导口吻、材料版本、机械来源与重复归属 |
| `scripts/reconcile_check.py` | 机械勾稽核验：股权求和=100%、人员分项=总数、客户合计、资产负债恒等式、毛利率反算等 |
| `scripts/extract_docx.py` | 读取 .docx 资料包，逐块输出段落与表格便于建台账 |
| `assets/content_skeleton.json` | content.json 骨架样例 |
| `assets/fonts/` | 本机授权字体准备说明（不含字体文件） |
| `evals/evals.json` | 骨架及证据边界回归场景，以及修订、融资简写、财务和订单分析的虚构用例 |

## 脚本用法

```bash
# 勾稽核验（仅标准库，任何 Python 可跑；FAIL 时退出码 2）
python scripts/reconcile_check.py content.json

# 语言红线机械扫描（仅标准库；命中时退出码 1）
python scripts/style_check.py content.json

# 生成 Word（依赖 python-docx；生成前先保障字体）
python scripts/ensure_fonts.py
python scripts/build_docx.py content.json output.docx

# 读取 docx 资料包（依赖 python-docx）
python scripts/extract_docx.py "某公司-尽调资料.docx" out.txt
```

## v2.0 升级要点（2026-07）

- 新增**语言红线**并置于全流程第一优先级：禁用"不是而是"类否定-肯定对照连词族（附逐条改写示范）、禁用"标的公司"类称谓、结论先行，质检清单前四项专查语言。
- 新增**会议纪要挖掘协议**：十类纪要独家信息对号入座到章节位置，每条"公司说法"先分类（可书面验证→生成核查任务／仅口头→挂口径照录）再落笔；三角验证矩阵扩至 14 对（新增纪要↔书面文件互锁）。
- 联网检索聚焦为**三大必检**，股东背景列升级为标准动作（"机构简称，资金性质"格式）。
- 此处为历史版本记录；当前已升级为先询问阶段、按原报告固定模板填空。旧四节制及自动增配规则停用。
- 基于范文逐字复核补齐**文体指纹**：称谓两分法、转折只用"但"、引导句冒号收尾、客户供应商节纯表格、财务分析段以简称开头等。
- 修复 `reconcile_check.py` 合计行识别缺陷（合计标记在序号列时曾被当明细重复求和），并支持"前10大小计/总收入"两级合计与"收入额/价税合计"表头；已用两篇范文真实数据完成正反向冒烟测试。

## 审阅批注吸收（2026-09）

根据一份早期立项报告多轮审阅批注与修订（已脱敏，不含项目事实）更新：

- 设立背景首句交代控股股东/实控人及其直接、穿透持股与背景；实控人关联的同名、近名企业写清关系；任职与持股写“曾任/现任/至今”；
- 数据段首句写结论和影响，避免“这段想表达什么”；
- 融资表（T13）逐轮列估值、对赌及回购（写明义务主体）与其他特殊条款；新增可比估值表（T16）与估值合理性四步写法；
- 意向订单按业务板块拆分（T17），单独写深度合作、绑定大客户与中标工程；
- `style_check.py` 新增数值范围（“7万—10万元”）、半角括号、不规范用词扫描，排他论断与任职时点不明给警告；`build_docx.py` 新增 `image` 块（产品实物照片等）。

## 终稿范式升级（2026-09-23）

依据一份经多轮审阅定稿的早前期立项报告（内部文件，事实不入库）升级：

- 早前期模板改为终稿结构（28个源标题）：设立背景开篇，新增关联公司及经营主体、资质及荣誉、本轮融资及资金使用计划、公司收入预测及订单依据（已签、意向）；历史股权变动不再逐次设标题，财务问题并入核心财务数据分析段；
- `structure.md` 新增“早前期终稿范式逐节写法”与改写规律；新增表模板 T18—T21；
- 三技能共用的投资逻辑复核新增全报告逻辑主线、论据强度分级与简明公文表达；
- `style_check.py` 新增方法论/告诫句与内部资料编号扫描；`build_docx.py` 段落块支持 `lead`。

## 数字千位分隔（2026-09-28）

- 公文格式硬规则新增第 8 条：阿拉伯数字按英美通行写法三位分节，整数部分四位及以上自个位起每三位加半角逗号、小数点用半角点（`1,234.56`、`2,350万元`、`1,000,000`），正文、表格、括注、附件一律适用；年份、日期、文号、编号、代码、电话、证件号、标准号等标识性数字不加逗号；
- `style_check.py` 新增未分节数字扫描（硬规则），参考资料和范例中的数字同步改为分节写法。

## 跨 Agent 安装与调用

[下载完整技能 ZIP](https://github.com/Icdafy/Skills/raw/refs/heads/main/distributions/investment-report-skills/gongsi-qingkuang.zip)。Claude、ChatGPT、Codex、Kimi、豆包、智谱 GLM（ZCode、AutoClaw）、WorkBuddy、TRAE、Qoder 的安装入口、目录差异和验收见 [跨 Agent 安装与调用](references/agent-compatibility.md)。

本技能名为 `gongsi-qingkuang`。保留完整文件夹，启用后新建会话点名调用；可运行 `python scripts/skill_portability.py check --smoke` 检查资源及Word生成。技能发现与模型实际调用须在目标客户端按指引验收，不能仅凭复制文件认定成功。
