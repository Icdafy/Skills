#!/usr/bin/env python3
"""Read a generated minutes DOCX back and confirm every run carries the font,
size and weight the layout spec prescribes — without rendering to PDF.

The content-fidelity check in ``check_all.py`` proves the DOCX carries the right
*text*; this proves it carries the right *formatting*. Each body paragraph's
expected face is re-derived from ``format_spec.paragraph_role`` (the same
function the renderer uses), western runs must be Times New Roman, and the
centred title/subtitle are checked against their fixed faces. Headers must be
empty, while odd/even footers must carry the exact page-number field, font,
size and alignment from ``format_spec``. Any drift is therefore caught here
instead of only by a human eyeballing the PDF.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import sys

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.shared import Pt

sys.path.insert(0, str(Path(__file__).resolve().parent))
from format_spec import (  # noqa: E402  (needs the path shim above)
    BODY_SIZE,
    BODY_LINE_SPACING,
    HEADING_LINE_SPACING,
    TITLE_LINE_SPACING,
    SUBTITLE_LINE_SPACING,
    KAI_FONT,
    NUMBER_FONT,
    PAGE_NUMBER_FONT,
    PAGE_NUMBER_FONT_HINT,
    PAGE_NUMBER_FONT_SLOTS,
    PAGE_NUMBER_PREFIX,
    PAGE_NUMBER_SIZE,
    PAGE_NUMBER_SUFFIX,
    SUBTITLE_SIZE,
    TABLE_FONT,
    TABLE_SIZE,
    TITLE_FONT,
    TITLE_SIZE,
    WESTERN_SEGMENT,
    paragraph_role,
)
from docx_format_helpers import parenthesized_spans  # noqa: E402


def _east_asia(run) -> str | None:
    rpr = run._element.rPr
    if rpr is None or rpr.rFonts is None:
        return None
    return rpr.rFonts.get(qn("w:eastAsia"))


def _is_western(text: str) -> bool:
    return WESTERN_SEGMENT.fullmatch(text) is not None


def _expected(paragraph, center_seen: int) -> tuple[str, int, bool, int] | None:
    """Return (east-asia font, size pt, bold, line spacing) for this paragraph, or
    None to skip it (blank line / spacer)."""
    text = paragraph.text.strip()
    if not text:
        return None
    if paragraph.alignment == WD_ALIGN_PARAGRAPH.CENTER:
        # First centred line is the title; any later centred line is the subtitle.
        if center_seen == 0:
            return TITLE_FONT, TITLE_SIZE, False, TITLE_LINE_SPACING
        return KAI_FONT, SUBTITLE_SIZE, False, SUBTITLE_LINE_SPACING
    role, font, bold = paragraph_role(text)
    spacing = HEADING_LINE_SPACING if role != "body" else BODY_LINE_SPACING
    return font, BODY_SIZE, bold, spacing


def _part_text(part) -> str:
    """Visible text in a header/footer part, including field result text."""
    return "".join(node.text or "" for node in part._element.iter(qn("w:t")))


def _footer_pattern(paragraph) -> str:
    """Represent the generated simple PAGE field as ``{PAGE}``."""
    parts: list[str] = []
    for child in paragraph._p:
        if child.tag == qn("w:r"):
            parts.append("".join(node.text or "" for node in child.iter(qn("w:t"))))
        elif child.tag == qn("w:fldSimple"):
            instruction = (child.get(qn("w:instr")) or "").strip()
            parts.append("{PAGE}" if instruction == "PAGE" else f"{{{instruction}}}")
    return "".join(parts)


def _footer_run_problems(paragraph, label: str) -> list[str]:
    problems: list[str] = []
    expected_size = str(PAGE_NUMBER_SIZE * 2)
    visible_runs = []
    for run in paragraph._p.iter(qn("w:r")):
        text = "".join(node.text or "" for node in run.iter(qn("w:t")))
        if not text:
            continue
        visible_runs.append((run, text))
    for index, (run, text) in enumerate(visible_runs):
        if run.getparent() is not None and run.getparent().tag == qn("w:fldSimple"):
            component = "PAGE 域显示数字"
        elif index == 0:
            component = "左短横线"
        elif index == len(visible_runs) - 1:
            component = "右短横线"
        else:
            component = f"可见组成部分「{text}」"
        properties = run.find(qn("w:rPr"))
        fonts = None if properties is None else properties.find(qn("w:rFonts"))
        for attribute in PAGE_NUMBER_FONT_SLOTS:
            actual = None if fonts is None else fonts.get(qn(f"w:{attribute}"))
            if actual != PAGE_NUMBER_FONT:
                problems.append(
                    f"{label}{component}的 {attribute} 字体为 {actual}，应为 {PAGE_NUMBER_FONT}"
                )
        actual_hint = None if fonts is None else fonts.get(qn("w:hint"))
        if actual_hint != PAGE_NUMBER_FONT_HINT:
            problems.append(
                f"{label}{component}的字体提示为 {actual_hint}，应为 {PAGE_NUMBER_FONT_HINT}"
            )
        for tag, size_label in (("w:sz", "sz"), ("w:szCs", "szCs")):
            size = None if properties is None else properties.find(qn(tag))
            actual_size = None if size is None else size.get(qn("w:val"))
            if actual_size != expected_size:
                try:
                    got = None if actual_size is None else int(actual_size) / 2
                except ValueError:
                    got = actual_size
                problems.append(
                    f"{label}{component}的 {size_label} 字号为 {got} 磅，"
                    f"应为 {PAGE_NUMBER_SIZE} 磅"
                )
    return problems


def _page_number_defaults_problems(properties, label: str) -> list[str]:
    problems: list[str] = []
    fonts = None if properties is None else properties.find(qn("w:rFonts"))
    for attribute in PAGE_NUMBER_FONT_SLOTS:
        actual = None if fonts is None else fonts.get(qn(f"w:{attribute}"))
        if actual != PAGE_NUMBER_FONT:
            problems.append(f"{label}的 {attribute} 字体为 {actual}，应为 {PAGE_NUMBER_FONT}")
    actual_hint = None if fonts is None else fonts.get(qn("w:hint"))
    if actual_hint != PAGE_NUMBER_FONT_HINT:
        problems.append(f"{label}的字体提示为 {actual_hint}，应为 {PAGE_NUMBER_FONT_HINT}")
    expected_size = str(PAGE_NUMBER_SIZE * 2)
    for tag, size_label in (("w:sz", "sz"), ("w:szCs", "szCs")):
        size = None if properties is None else properties.find(qn(tag))
        actual = None if size is None else size.get(qn("w:val"))
        if actual != expected_size:
            problems.append(f"{label}的 {size_label} 应为 {expected_size}")
    return problems


def _page_frame_problems(document) -> list[str]:
    problems: list[str] = []
    if not document.settings.odd_and_even_pages_header_footer:
        problems.append("未启用奇偶页不同的页眉页脚")

    footer_style_properties = document.styles["Footer"]._element.find(qn("w:rPr"))
    problems.extend(
        _page_number_defaults_problems(footer_style_properties, "Footer 样式")
    )

    expected_pattern = f"{PAGE_NUMBER_PREFIX}{{PAGE}}{PAGE_NUMBER_SUFFIX}"
    for index, section in enumerate(document.sections, start=1):
        prefix = f"第 {index} 节"
        if section.different_first_page_header_footer:
            problems.append(f"{prefix}启用了首页不同页眉页脚，应关闭")
        for label, header in (
            ("奇数页页眉", section.header),
            ("偶数页页眉", section.even_page_header),
            ("首页页眉", section.first_page_header),
        ):
            if _part_text(header).strip():
                problems.append(f"{prefix}{label}应为空，实际为「{_part_text(header).strip()}」")

        for label, footer, alignment in (
            ("奇数页页脚", section.footer, WD_ALIGN_PARAGRAPH.RIGHT),
            ("偶数页页脚", section.even_page_footer, WD_ALIGN_PARAGRAPH.LEFT),
        ):
            paragraphs = footer.paragraphs
            numbered = [p for p in paragraphs if "{PAGE}" in _footer_pattern(p)]
            if len(numbered) != 1:
                problems.append(f"{prefix}{label}应包含且仅包含一个 PAGE 页码域")
                continue
            paragraph = numbered[0]
            extras = [
                p for p in paragraphs
                if p._p is not paragraph._p and _footer_pattern(p).strip()
            ]
            if extras:
                problems.append(f"{prefix}{label}含页码以外的内容")
            actual_pattern = _footer_pattern(paragraph)
            if actual_pattern != expected_pattern:
                problems.append(
                    f"{prefix}{label}页码格式为「{actual_pattern}」，应为「{expected_pattern}」"
                )
            if paragraph.alignment != alignment:
                want = "右对齐" if alignment == WD_ALIGN_PARAGRAPH.RIGHT else "左对齐"
                problems.append(f"{prefix}{label}未{want}")
            paragraph_properties = paragraph._p.get_or_add_pPr().find(qn("w:rPr"))
            problems.extend(
                _page_number_defaults_problems(
                    paragraph_properties, f"{prefix}{label}段落默认字符属性"
                )
            )
            problems.extend(_footer_run_problems(paragraph, f"{prefix}{label}"))
    return problems


def check_docx_style(path: Path) -> list[str]:
    document = Document(str(path))
    problems: list[str] = []
    center_seen = 0
    for paragraph in document.paragraphs:
        expected = _expected(paragraph, center_seen)
        if paragraph.alignment == WD_ALIGN_PARAGRAPH.CENTER and paragraph.text.strip():
            center_seen += 1
        if expected is None:
            if not paragraph.text.strip() and (
                paragraph.paragraph_format.line_spacing_rule != WD_LINE_SPACING.EXACTLY
                or paragraph.paragraph_format.line_spacing != Pt(BODY_LINE_SPACING)
            ):
                problems.append(
                    f"空白分隔段行距应为固定值 {BODY_LINE_SPACING} 磅"
                )
            continue
        ea_font, size, bold, spacing = expected
        preview = paragraph.text.strip()[:20]
        if (paragraph.paragraph_format.line_spacing_rule != WD_LINE_SPACING.EXACTLY
                or paragraph.paragraph_format.line_spacing != Pt(spacing)):
            problems.append(f"「{preview}」行距应为固定值 {spacing} 磅")
        problems.extend(_run_problems(paragraph, preview, ea_font, size, bold, BODY_SIZE))
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    if not paragraph.text.strip():
                        continue
                    preview = "表格：" + paragraph.text.strip()[:16]
                    problems.extend(_run_problems(
                        paragraph, preview, TABLE_FONT, TABLE_SIZE, False, TABLE_SIZE))
    problems.extend(_page_frame_problems(document))
    return problems


def _run_problems(paragraph, preview: str, ea_font: str, size: float, bold: bool,
                  paren_size: float) -> list[str]:
    """Every run: Western slots Times New Roman; East Asian face per role
    (楷体_GB2312 inside parentheses); size and weight per role."""
    problems: list[str] = []
    spans = parenthesized_spans(paragraph.text)
    offset = 0
    for run in paragraph.runs:
        start, end = offset, offset + len(run.text)
        offset = end
        if not run.text.strip():
            continue
        inside = any(a <= start and end <= b for a, b in spans)
        if not inside and any(a < end and start < b for a, b in spans):
            problems.append(f"「{preview}」括号片段与外围文字应拆分设置字体")
        run_ea = KAI_FONT if inside else ea_font
        run_size = paren_size if inside else size
        fonts = run._element.rPr.rFonts if run._element.rPr is not None else None
        for attribute in ("ascii", "hAnsi", "cs"):
            actual = None if fonts is None else fonts.get(qn("w:" + attribute))
            if actual != NUMBER_FONT:
                problems.append(
                    f"「{preview}」中「{run.text[:12]}」西文字体（{attribute}）为 {actual}，"
                    f"应为 {NUMBER_FONT}"
                )
        if _east_asia(run) != run_ea:
            problems.append(
                f"「{preview}」中「{run.text[:12]}」东亚字体为 {_east_asia(run)}，应为 {run_ea}"
            )
        if run.font.size != Pt(run_size):
            got = None if run.font.size is None else round(run.font.size.pt, 1)
            problems.append(
                f"「{preview}」中「{run.text[:12]}」字号为 {got} 磅，应为 {run_size} 磅"
            )
        if bool(run.bold) != bold:
            problems.append(
                f"「{preview}」中「{run.text[:12]}」加粗为 {bool(run.bold)}，应为 {bold}"
            )
    return problems


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("docx", type=Path, help="generated minutes DOCX")
    args = parser.parse_args()
    if not args.docx.is_file():
        print(f"找不到 DOCX：{args.docx}")
        return 2
    problems = check_docx_style(args.docx)
    if problems:
        print("DOCX 样式回读未通过：")
        for problem in problems:
            print(f"- {problem}")
        return 1
    print("DOCX 样式回读通过：正文及页眉页脚的字体、字号、加粗与版式均符合规约。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
